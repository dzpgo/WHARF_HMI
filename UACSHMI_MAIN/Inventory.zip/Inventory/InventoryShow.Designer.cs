﻿namespace Inventory
{
    partial class InventoryShow
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checBox_All_Details = new System.Windows.Forms.CheckBox();
            this.dgvDetail = new System.Windows.Forms.DataGridView();
            this.CheckedColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SCAN_TIME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.USR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Stock_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MAT_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.INVENT_RESULT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.REMARK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RESULT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.STOCK_NO_IMPLICATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.checBox_All_Checks = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dgvCheck = new System.Windows.Forms.DataGridView();
            this.CHECK_FLAG = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CHECK_SCAN_TIME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Stock_No1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Coil_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DROP_MAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CHECK_RESULT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MAT_NO_FIRST = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BATCH_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.button_DelRecord = new System.Windows.Forms.Button();
            this.button_KillStock = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_ForceConfirm = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtStockNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSeachMat = new System.Windows.Forms.Button();
            this.txtMatNo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbxAreaNo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbId = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.refreshDgvTimer = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetail)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCheck)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1210, 733);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 57);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.35816F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.64184F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1210, 631);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checBox_All_Details);
            this.groupBox1.Controls.Add(this.dgvDetail);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1204, 336);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "盘库清单";
            // 
            // checBox_All_Details
            // 
            this.checBox_All_Details.AutoSize = true;
            this.checBox_All_Details.Location = new System.Drawing.Point(9, 22);
            this.checBox_All_Details.Name = "checBox_All_Details";
            this.checBox_All_Details.Size = new System.Drawing.Size(51, 21);
            this.checBox_All_Details.TabIndex = 7;
            this.checBox_All_Details.Text = "全选";
            this.checBox_All_Details.UseVisualStyleBackColor = true;
            this.checBox_All_Details.CheckedChanged += new System.EventHandler(this.checBox_All_Details_CheckedChanged);
            // 
            // dgvDetail
            // 
            this.dgvDetail.AllowUserToAddRows = false;
            this.dgvDetail.AllowUserToResizeRows = false;
            this.dgvDetail.BackgroundColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDetail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvDetail.ColumnHeadersHeight = 28;
            this.dgvDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvDetail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CheckedColumn,
            this.SEQ,
            this.SCAN_TIME,
            this.USR,
            this.ID,
            this.Stock_No,
            this.MAT_NO,
            this.Column5,
            this.INVENT_RESULT,
            this.REMARK,
            this.Column8,
            this.RESULT,
            this.STOCK_NO_IMPLICATE,
            this.Column9,
            this.Column4});
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDetail.DefaultCellStyle = dataGridViewCellStyle10;
            this.dgvDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDetail.EnableHeadersVisualStyles = false;
            this.dgvDetail.Location = new System.Drawing.Point(3, 19);
            this.dgvDetail.Name = "dgvDetail";
            this.dgvDetail.RowHeadersVisible = false;
            this.dgvDetail.RowTemplate.Height = 23;
            this.dgvDetail.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetail.Size = new System.Drawing.Size(1198, 314);
            this.dgvDetail.TabIndex = 6;
            this.dgvDetail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDetail_CellContentClick);
            this.dgvDetail.Scroll += new System.Windows.Forms.ScrollEventHandler(this.dgvDetail_Scroll);
            // 
            // CheckedColumn
            // 
            this.CheckedColumn.FillWeight = 487.3096F;
            this.CheckedColumn.Frozen = true;
            this.CheckedColumn.HeaderText = "              ";
            this.CheckedColumn.Name = "CheckedColumn";
            this.CheckedColumn.Width = 70;
            // 
            // SEQ
            // 
            this.SEQ.DataPropertyName = "SEQ";
            this.SEQ.Frozen = true;
            this.SEQ.HeaderText = "";
            this.SEQ.Name = "SEQ";
            this.SEQ.ReadOnly = true;
            this.SEQ.Width = 35;
            // 
            // SCAN_TIME
            // 
            this.SCAN_TIME.DataPropertyName = "SCAN_TIME";
            this.SCAN_TIME.Frozen = true;
            this.SCAN_TIME.HeaderText = "扫描时间";
            this.SCAN_TIME.Name = "SCAN_TIME";
            this.SCAN_TIME.ReadOnly = true;
            this.SCAN_TIME.Width = 110;
            // 
            // USR
            // 
            this.USR.DataPropertyName = "USER";
            this.USR.FillWeight = 64.79003F;
            this.USR.HeaderText = "工号";
            this.USR.Name = "USR";
            this.USR.Width = 57;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.FillWeight = 64.79003F;
            this.ID.HeaderText = "盘库单号";
            this.ID.Name = "ID";
            this.ID.Visible = false;
            this.ID.Width = 81;
            // 
            // Stock_No
            // 
            this.Stock_No.DataPropertyName = "STOCK_NO";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Stock_No.DefaultCellStyle = dataGridViewCellStyle9;
            this.Stock_No.FillWeight = 64.79003F;
            this.Stock_No.HeaderText = "库 位";
            this.Stock_No.Name = "Stock_No";
            this.Stock_No.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Stock_No.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Stock_No.Width = 82;
            // 
            // MAT_NO
            // 
            this.MAT_NO.DataPropertyName = "MAT_NO";
            this.MAT_NO.FillWeight = 64.79003F;
            this.MAT_NO.HeaderText = "实 物";
            this.MAT_NO.Name = "MAT_NO";
            this.MAT_NO.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.MAT_NO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MAT_NO.Width = 102;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "DROP_MAT";
            this.Column5.FillWeight = 64.79003F;
            this.Column5.HeaderText = "信 息";
            this.Column5.Name = "Column5";
            this.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column5.Width = 102;
            // 
            // INVENT_RESULT
            // 
            this.INVENT_RESULT.DataPropertyName = "INVENT_RESULT";
            this.INVENT_RESULT.HeaderText = "比对结果";
            this.INVENT_RESULT.Name = "INVENT_RESULT";
            this.INVENT_RESULT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.INVENT_RESULT.Width = 67;
            // 
            // REMARK
            // 
            this.REMARK.DataPropertyName = "REMARK";
            this.REMARK.FillWeight = 64.79003F;
            this.REMARK.HeaderText = "是否需要复核";
            this.REMARK.Name = "REMARK";
            this.REMARK.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.REMARK.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.REMARK.Width = 150;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "ACTION";
            this.Column8.FillWeight = 64.79003F;
            this.Column8.HeaderText = "库位动作";
            this.Column8.Name = "Column8";
            this.Column8.Width = 102;
            // 
            // RESULT
            // 
            this.RESULT.DataPropertyName = "RESULT";
            this.RESULT.FillWeight = 64.79003F;
            this.RESULT.HeaderText = "动作结果";
            this.RESULT.Name = "RESULT";
            this.RESULT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.RESULT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RESULT.Width = 102;
            // 
            // STOCK_NO_IMPLICATE
            // 
            this.STOCK_NO_IMPLICATE.DataPropertyName = "STOCK_NO_IMPLICATE";
            this.STOCK_NO_IMPLICATE.FillWeight = 64.79003F;
            this.STOCK_NO_IMPLICATE.HeaderText = "牵连库位";
            this.STOCK_NO_IMPLICATE.Name = "STOCK_NO_IMPLICATE";
            this.STOCK_NO_IMPLICATE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.STOCK_NO_IMPLICATE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.STOCK_NO_IMPLICATE.Width = 102;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "ACTION_IMPLICATE";
            this.Column9.FillWeight = 64.79003F;
            this.Column9.HeaderText = "牵连库位动作";
            this.Column9.Name = "Column9";
            this.Column9.Width = 105;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "RESULT_IMPLICATE";
            this.Column4.FillWeight = 64.79003F;
            this.Column4.HeaderText = "牵连库位结果";
            this.Column4.Name = "Column4";
            this.Column4.Width = 105;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBox1);
            this.groupBox2.Controls.Add(this.checBox_All_Checks);
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Controls.Add(this.dgvCheck);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(3, 345);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1204, 283);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "复核清单";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.Info;
            this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 17;
            this.listBox1.Items.AddRange(new object[] {
            "库位最近吊运实绩"});
            this.listBox1.Location = new System.Drawing.Point(1021, 19);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(180, 261);
            this.listBox1.TabIndex = 47;
            // 
            // checBox_All_Checks
            // 
            this.checBox_All_Checks.AutoSize = true;
            this.checBox_All_Checks.Location = new System.Drawing.Point(9, 22);
            this.checBox_All_Checks.Name = "checBox_All_Checks";
            this.checBox_All_Checks.Size = new System.Drawing.Size(51, 21);
            this.checBox_All_Checks.TabIndex = 6;
            this.checBox_All_Checks.Text = "全选";
            this.checBox_All_Checks.UseVisualStyleBackColor = true;
            this.checBox_All_Checks.CheckedChanged += new System.EventHandler(this.checBox_All_Checks_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button5);
            this.panel4.Controls.Add(this.btnCreate);
            this.panel4.Controls.Add(this.button4);
            this.panel4.Location = new System.Drawing.Point(149, 139);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(91, 117);
            this.panel4.TabIndex = 44;
            this.panel4.Visible = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(101)))), ((int)(((byte)(175)))));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(0, 57);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(91, 26);
            this.button5.TabIndex = 37;
            this.button5.Text = "预览";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Visible = false;
            // 
            // btnCreate
            // 
            this.btnCreate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(101)))), ((int)(((byte)(175)))));
            this.btnCreate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCreate.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCreate.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnCreate.ForeColor = System.Drawing.Color.White;
            this.btnCreate.Location = new System.Drawing.Point(0, 26);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(91, 31);
            this.btnCreate.TabIndex = 38;
            this.btnCreate.Text = "创建盘库单";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(101)))), ((int)(((byte)(175)))));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(0, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 26);
            this.button4.TabIndex = 40;
            this.button4.Text = "关闭盘库单";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Visible = false;
            // 
            // dgvCheck
            // 
            this.dgvCheck.AllowUserToAddRows = false;
            this.dgvCheck.AllowUserToResizeRows = false;
            this.dgvCheck.BackgroundColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCheck.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvCheck.ColumnHeadersHeight = 28;
            this.dgvCheck.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvCheck.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CHECK_FLAG,
            this.Column10,
            this.CHECK_SCAN_TIME,
            this.Stock_No1,
            this.Coil_no,
            this.DROP_MAT,
            this.dataGridViewTextBoxColumn8,
            this.CHECK_RESULT,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn9,
            this.Column11,
            this.MAT_NO_FIRST,
            this.BATCH_ID});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCheck.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgvCheck.Dock = System.Windows.Forms.DockStyle.Left;
            this.dgvCheck.EnableHeadersVisualStyles = false;
            this.dgvCheck.Location = new System.Drawing.Point(3, 19);
            this.dgvCheck.Name = "dgvCheck";
            this.dgvCheck.RowHeadersVisible = false;
            this.dgvCheck.RowTemplate.Height = 23;
            this.dgvCheck.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCheck.Size = new System.Drawing.Size(1018, 261);
            this.dgvCheck.TabIndex = 7;
            this.dgvCheck.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCheck_CellContentClick);
            this.dgvCheck.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCheck_CellContentDoubleClick);
            this.dgvCheck.Scroll += new System.Windows.Forms.ScrollEventHandler(this.dgvCheck_Scroll);
            // 
            // CHECK_FLAG
            // 
            this.CHECK_FLAG.Frozen = true;
            this.CHECK_FLAG.HeaderText = "";
            this.CHECK_FLAG.Name = "CHECK_FLAG";
            this.CHECK_FLAG.Width = 70;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "ID";
            this.Column10.HeaderText = "盘库单号";
            this.Column10.Name = "Column10";
            this.Column10.Visible = false;
            this.Column10.Width = 120;
            // 
            // CHECK_SCAN_TIME
            // 
            this.CHECK_SCAN_TIME.DataPropertyName = "SCAN_TIME";
            this.CHECK_SCAN_TIME.Frozen = true;
            this.CHECK_SCAN_TIME.HeaderText = "复核时间";
            this.CHECK_SCAN_TIME.Name = "CHECK_SCAN_TIME";
            this.CHECK_SCAN_TIME.ReadOnly = true;
            this.CHECK_SCAN_TIME.Width = 110;
            // 
            // Stock_No1
            // 
            this.Stock_No1.DataPropertyName = "STOCK_NO";
            this.Stock_No1.Frozen = true;
            this.Stock_No1.HeaderText = "库位号";
            this.Stock_No1.Name = "Stock_No1";
            this.Stock_No1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Stock_No1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Stock_No1.Width = 120;
            // 
            // Coil_no
            // 
            this.Coil_no.DataPropertyName = "MAT_NO";
            this.Coil_no.Frozen = true;
            this.Coil_no.HeaderText = "实 物";
            this.Coil_no.Name = "Coil_no";
            this.Coil_no.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Coil_no.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Coil_no.Width = 120;
            // 
            // DROP_MAT
            // 
            this.DROP_MAT.DataPropertyName = "DROP_MAT";
            this.DROP_MAT.Frozen = true;
            this.DROP_MAT.HeaderText = "信 息";
            this.DROP_MAT.Name = "DROP_MAT";
            this.DROP_MAT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DROP_MAT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DROP_MAT.Width = 120;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "ACTION";
            this.dataGridViewTextBoxColumn8.Frozen = true;
            this.dataGridViewTextBoxColumn8.HeaderText = "操作";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 120;
            // 
            // CHECK_RESULT
            // 
            this.CHECK_RESULT.DataPropertyName = "RESULT";
            this.CHECK_RESULT.Frozen = true;
            this.CHECK_RESULT.HeaderText = "比对结果";
            this.CHECK_RESULT.Name = "CHECK_RESULT";
            this.CHECK_RESULT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CHECK_RESULT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "REMARK";
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "备注";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 170;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "STOCK_NO_IMPLICATE";
            this.dataGridViewTextBoxColumn7.Frozen = true;
            this.dataGridViewTextBoxColumn7.HeaderText = "牵连库位";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Visible = false;
            this.dataGridViewTextBoxColumn7.Width = 120;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ACTION_IMPLICATE";
            this.dataGridViewTextBoxColumn9.Frozen = true;
            this.dataGridViewTextBoxColumn9.HeaderText = "牵连库位操作";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Visible = false;
            this.dataGridViewTextBoxColumn9.Width = 120;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "RESULT_IMPLICATE";
            this.Column11.Frozen = true;
            this.Column11.HeaderText = "牵连库位操作结果";
            this.Column11.Name = "Column11";
            this.Column11.Visible = false;
            this.Column11.Width = 120;
            // 
            // MAT_NO_FIRST
            // 
            this.MAT_NO_FIRST.DataPropertyName = "MAT_NO_FIRST";
            this.MAT_NO_FIRST.HeaderText = "初盘材料";
            this.MAT_NO_FIRST.Name = "MAT_NO_FIRST";
            this.MAT_NO_FIRST.Visible = false;
            this.MAT_NO_FIRST.Width = 120;
            // 
            // BATCH_ID
            // 
            this.BATCH_ID.DataPropertyName = "BATCH_ID";
            this.BATCH_ID.HeaderText = "批次号";
            this.BATCH_ID.Name = "BATCH_ID";
            this.BATCH_ID.Visible = false;
            this.BATCH_ID.Width = 120;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.button_DelRecord);
            this.panel3.Controls.Add(this.button_KillStock);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.btn_ForceConfirm);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 688);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1210, 45);
            this.panel3.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(4, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(453, 12);
            this.label5.TabIndex = 48;
            this.label5.Text = "比对结果 (含义1:实物信息一致 0:实物信息不一致 2:实物有卷,信息可落卷)";
            // 
            // button_DelRecord
            // 
            this.button_DelRecord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(101)))), ((int)(((byte)(175)))));
            this.button_DelRecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_DelRecord.Dock = System.Windows.Forms.DockStyle.Right;
            this.button_DelRecord.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_DelRecord.ForeColor = System.Drawing.Color.White;
            this.button_DelRecord.Location = new System.Drawing.Point(648, 0);
            this.button_DelRecord.Name = "button_DelRecord";
            this.button_DelRecord.Size = new System.Drawing.Size(114, 45);
            this.button_DelRecord.TabIndex = 42;
            this.button_DelRecord.TabStop = false;
            this.button_DelRecord.Text = "删除记录";
            this.button_DelRecord.UseVisualStyleBackColor = false;
            this.button_DelRecord.Click += new System.EventHandler(this.button_DelRecord_Click);
            // 
            // button_KillStock
            // 
            this.button_KillStock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(101)))), ((int)(((byte)(175)))));
            this.button_KillStock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_KillStock.Dock = System.Windows.Forms.DockStyle.Right;
            this.button_KillStock.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_KillStock.ForeColor = System.Drawing.Color.White;
            this.button_KillStock.Location = new System.Drawing.Point(762, 0);
            this.button_KillStock.Name = "button_KillStock";
            this.button_KillStock.Size = new System.Drawing.Size(114, 45);
            this.button_KillStock.TabIndex = 44;
            this.button_KillStock.Text = "封锁库位";
            this.button_KillStock.UseVisualStyleBackColor = false;
            this.button_KillStock.Click += new System.EventHandler(this.button_KillStock_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(101)))), ((int)(((byte)(175)))));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Dock = System.Windows.Forms.DockStyle.Right;
            this.button1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(876, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 45);
            this.button1.TabIndex = 46;
            this.button1.TabStop = false;
            this.button1.Text = "复核确认";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // btn_ForceConfirm
            // 
            this.btn_ForceConfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(101)))), ((int)(((byte)(175)))));
            this.btn_ForceConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_ForceConfirm.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_ForceConfirm.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ForceConfirm.ForeColor = System.Drawing.Color.Red;
            this.btn_ForceConfirm.Location = new System.Drawing.Point(990, 0);
            this.btn_ForceConfirm.Name = "btn_ForceConfirm";
            this.btn_ForceConfirm.Size = new System.Drawing.Size(106, 45);
            this.btn_ForceConfirm.TabIndex = 41;
            this.btn_ForceConfirm.Text = "强制复核";
            this.btn_ForceConfirm.UseVisualStyleBackColor = false;
            this.btn_ForceConfirm.Click += new System.EventHandler(this.btn_ForceConfirm_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(101)))), ((int)(((byte)(175)))));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Dock = System.Windows.Forms.DockStyle.Right;
            this.button3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(1096, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 45);
            this.button3.TabIndex = 39;
            this.button3.Text = "盘库确认";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtStockNo);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.btnSeachMat);
            this.panel2.Controls.Add(this.txtMatNo);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.cbxAreaNo);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cbbId);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1210, 57);
            this.panel2.TabIndex = 0;
            // 
            // txtStockNo
            // 
            this.txtStockNo.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtStockNo.Location = new System.Drawing.Point(774, 10);
            this.txtStockNo.Name = "txtStockNo";
            this.txtStockNo.Size = new System.Drawing.Size(143, 23);
            this.txtStockNo.TabIndex = 44;
            this.txtStockNo.TabStop = false;
            this.txtStockNo.TextChanged += new System.EventHandler(this.txtStockNo_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(709, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 20);
            this.label2.TabIndex = 45;
            this.label2.Text = "库 位 号：";
            // 
            // btnSeachMat
            // 
            this.btnSeachMat.BackColor = System.Drawing.Color.White;
            this.btnSeachMat.BackgroundImage = global::Inventory.Properties.Resources.bg_btn;
            this.btnSeachMat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSeachMat.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSeachMat.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSeachMat.ForeColor = System.Drawing.Color.White;
            this.btnSeachMat.Location = new System.Drawing.Point(1072, 0);
            this.btnSeachMat.Name = "btnSeachMat";
            this.btnSeachMat.Size = new System.Drawing.Size(138, 57);
            this.btnSeachMat.TabIndex = 43;
            this.btnSeachMat.Text = "查询盘库记录";
            this.btnSeachMat.UseVisualStyleBackColor = false;
            this.btnSeachMat.Click += new System.EventHandler(this.btnSeachMat_Click);
            // 
            // txtMatNo
            // 
            this.txtMatNo.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtMatNo.Location = new System.Drawing.Point(556, 11);
            this.txtMatNo.Name = "txtMatNo";
            this.txtMatNo.Size = new System.Drawing.Size(143, 23);
            this.txtMatNo.TabIndex = 40;
            this.txtMatNo.TabStop = false;
            this.txtMatNo.TextChanged += new System.EventHandler(this.txtMatNo_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(491, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 41;
            this.label4.Text = "材 料 号：";
            // 
            // cbxAreaNo
            // 
            this.cbxAreaNo.BackColor = System.Drawing.SystemColors.MenuBar;
            this.cbxAreaNo.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbxAreaNo.FormattingEnabled = true;
            this.cbxAreaNo.Location = new System.Drawing.Point(322, 11);
            this.cbxAreaNo.Name = "cbxAreaNo";
            this.cbxAreaNo.Size = new System.Drawing.Size(154, 25);
            this.cbxAreaNo.TabIndex = 39;
            this.cbxAreaNo.TabStop = false;
            this.cbxAreaNo.SelectedIndexChanged += new System.EventHandler(this.cbxAreaNo_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(252, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 20);
            this.label1.TabIndex = 38;
            this.label1.Text = "盘库区域：";
            // 
            // cbbId
            // 
            this.cbbId.BackColor = System.Drawing.SystemColors.MenuBar;
            this.cbbId.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbbId.FormattingEnabled = true;
            this.cbbId.Location = new System.Drawing.Point(83, 11);
            this.cbbId.Name = "cbbId";
            this.cbbId.Size = new System.Drawing.Size(154, 25);
            this.cbbId.TabIndex = 37;
            this.cbbId.TabStop = false;
            this.cbbId.SelectedIndexChanged += new System.EventHandler(this.cbbId_SelectedIndexChanged);
            this.cbbId.Click += new System.EventHandler(this.cbbId_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(27, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 20);
            this.label3.TabIndex = 36;
            this.label3.Text = "盘库跨：";
            // 
            // refreshDgvTimer
            // 
            this.refreshDgvTimer.Interval = 3000;
            this.refreshDgvTimer.Tick += new System.EventHandler(this.refreshDgvTimer_Tick);
            // 
            // InventoryShow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1210, 733);
            this.Controls.Add(this.panel1);
            this.Name = "InventoryShow";
            this.Text = "盘库";
            this.Activated += new System.EventHandler(this.InventoryShow_Activated);
            this.Load += new System.EventHandler(this.InventoryShow_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetail)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCheck)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Baosight.iSuperframe.TagService.Controls.TagDataProvider tagDP = new Baosight.iSuperframe.TagService.Controls.TagDataProvider();
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_ForceConfirm;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cbbId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checBox_All_Checks;
        private System.Windows.Forms.CheckBox checBox_All_Details;
        private Baosight.iSuperframe.TagService.Controls.TagDataProvider tagDPrefresh = new Baosight.iSuperframe.TagService.Controls.TagDataProvider();
        private System.Windows.Forms.Button btnSeachMat;
        private System.Windows.Forms.TextBox txtMatNo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbxAreaNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvDetail;
        private System.Windows.Forms.DataGridView dgvCheck;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_KillStock;
        private System.Windows.Forms.Button button_DelRecord;
        private System.Windows.Forms.Timer refreshDgvTimer;
        private System.Windows.Forms.TextBox txtStockNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn STOCK_NO_IMPLICATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn RESULT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn REMARK;
        private System.Windows.Forms.DataGridViewTextBoxColumn INVENT_RESULT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAT_NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stock_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn USR;
        private System.Windows.Forms.DataGridViewTextBoxColumn SCAN_TIME;
        private System.Windows.Forms.DataGridViewTextBoxColumn SEQ;
        private System.Windows.Forms.DataGridViewCheckBoxColumn CheckedColumn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn BATCH_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAT_NO_FIRST;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn CHECK_RESULT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn DROP_MAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Coil_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stock_No1;
        private System.Windows.Forms.DataGridViewTextBoxColumn CHECK_SCAN_TIME;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewCheckBoxColumn CHECK_FLAG;
        private System.Windows.Forms.ListBox listBox1;
    }
}

